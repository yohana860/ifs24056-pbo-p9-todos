package org.delcom.todos.repositories;

import org.delcom.todos.entities.CashFlow;
import org.delcom.todos.types.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class CashFlowRepositoryTests {

    @Autowired
    private CashFlowRepository repository;

    @Test
    void testSaveAndFindByNamaItem() {
        // Buat data CashFlow baru
        CashFlow flow = new CashFlow(EType.INFLOW, ESource.CASH, "Hadiah", "Ulang tahun", 100000);

        // Simpan ke database (H2 test)
        repository.save(flow);

        // Cari berdasarkan nama item (case-insensitive)
        List<CashFlow> results = repository.findByNamaItemContainingIgnoreCase("hadiah");

        // Verifikasi hasil
        assertThat(results).isNotEmpty();
        assertThat(results.get(0).getNamaItem()).isEqualTo("Hadiah");
        assertThat(results.get(0).getAmount()).isEqualTo(100000);
        assertThat(results.get(0).getType()).isEqualTo(EType.INFLOW);
    }
}
