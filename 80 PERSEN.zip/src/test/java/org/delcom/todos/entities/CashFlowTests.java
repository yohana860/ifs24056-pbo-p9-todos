package org.delcom.todos.entities;

import org.delcom.todos.types.*;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class CashFlowEntityTest {

    @Test
    void testEntityFieldsAndMethods() {
        CashFlow flow = new CashFlow(EType.INFLOW, ESource.SAVINGS, "Tabungan", "Bulanan", 200000);
        flow.setKeteranganDetail("Dana pribadi");

        assertThat(flow.getType()).isEqualTo(EType.INFLOW);
        assertThat(flow.getSource()).isEqualTo(ESource.SAVINGS);
        assertThat(flow.getNamaItem()).isEqualTo("Tabungan");
        assertThat(flow.getKeteranganDetail()).isEqualTo("Dana pribadi");
    }
}
