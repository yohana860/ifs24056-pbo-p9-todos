package org.delcom.todos.types;

public class type {
  
}
